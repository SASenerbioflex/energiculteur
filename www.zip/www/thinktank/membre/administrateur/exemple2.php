<?php session_start();
include('header.php');
include('menuExemple.php');
?>
<div id="principal">
<div id="titre_principal">Le titre</div>
Votre texte ici</div>
<?php
include('footer.php');
?>
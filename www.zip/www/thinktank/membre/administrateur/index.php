<?php session_start();
include('header.php');
include('menu.php');

include('footer.php');
?>
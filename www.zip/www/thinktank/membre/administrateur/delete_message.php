<?php
include('../function.php');
Message::efface($_GET['id']);
?>
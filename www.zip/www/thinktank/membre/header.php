<?php
	$folder='../';
	include('function.php');
	include('../header.php');
?>
<?php
	$folder='../';
	include ($folder.'function.php');
	include($folder.'header_simple.php');
?>
<?php if(!isset($folder)) $folder=''; ?>
<!DOCTYPE html>
<html> 

	<head>

		<title>Enerbioflex</title>
	
		<meta charset="utf-8">
		
		<link rel="icon" type="image/png" href="<?php echo $folder ?>Images/favicon.ico" />
	
		<link rel="stylesheet" type="text/css" href="<?php echo $folder ?>css_simple.css">
		
		<meta name="viewport" content="width=device-width, initial-scale=1.0">


    </head>

	<body>
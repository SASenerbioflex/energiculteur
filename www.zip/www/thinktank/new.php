<!DOCTYPE html>
<?php
require ('connexion.php');
require ('header.php');
?>
<h1> En construction </h1>
<hr width="100%" color="2a95be"/>
<p> Ce contenu sera disponible sous peu.<p> 
<img id="erreur" src="<?php echo $folder?>Images/erreur.jpg" alt="erreur" /> 

<?php require('footer.php'); ?>
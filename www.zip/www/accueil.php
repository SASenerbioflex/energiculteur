

<?php
	require('header.php');
/*julien : test retirer identification au démarrage
	require_once('connexion.php');*/
?>	

<H3>Présentation d'énergiculteur : </H3>
	<div class="container">

		<div id="imgnews">
			<link rel="stylesheet" type="text/css" href="slider.css"/>
			<div class="boite">
						<div id="mask">
							
							<iframe frameborder="0" width="560" height="315" src="https://biteable.com/watch/embed/energiculteur-1371899/216053c5c1b88a14cb167c40d591359dca2e43f4" allowfullscreen="true"></iframe><p><a href="https://biteable.com/watch/energiculteur-1371899/216053c5c1b88a14cb167c40d591359dca2e43f4">energiculteur</a> on <a href="https://biteable.com">Biteable</a>.</p>
						</div>
						
						</div>		
			
			<div class="fb-page" data-href="https://www.facebook.com/enerbioflex" data-tabs="timeline" data-height="300" data-spacing="200" data-small-header="false" data-adapt-container-width="true" data-hide-cover="false" data-show-facepile="true"><blockquote cite="https://www.facebook.com/enerbioflex" class="fb-xfbml-parse-ignore"><a href="https://www.facebook.com/enerbioflex">Enerbioflex</a></blockquote></div>
				
			</div>

		
		
		<section class="post">
		<h2> Derniers Posts</h2>
		<hr width="100%" color=2a95be"/> /*************/
		
			
		<div class="divResult">
  <div class="tabPointO ">
  </div>
    <div class="tabPointO2">
  </div>
    <div class="tabPointO3">
  </div>
</div>
	
<?php
require('footer.php')
?>

	
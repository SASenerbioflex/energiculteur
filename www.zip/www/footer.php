
		</div> <!--Main-->

		<footer >
			
			
				<section class="partenaire">
	
	
					<img class="partenaireLogo" src="<?php echo $folder ?>Images/partenaire.jpg" alt="logo"  /> 
					<img class="partenaireLogo" src="<?php echo $folder ?>Images/partenaire1.jpg" alt="logo"  /> 
					<img class="partenaireLogo" src="<?php echo $folder ?>Images/partenaire2.png" alt="logo"  /> 
					<img class="partenaireLogo" src="<?php echo $folder ?>Images/partenaire3.jpg" alt="logo"  /> 
					<img class="partenaireLogo" src="<?php echo $folder ?>Images/partenaire4.png" alt="logo"  /> 
					<img class="partenaireLogo" src="<?php echo $folder ?>Images/partenaire5.png" alt="logo"  /> 
					<br/>
					
			
				</section>
				
				<section id="bas-de-page">
						
						 <span>Contact: enerbioflex@gmail.com </span>
						 <span>EnerBioFlex, 9 rue de la Prairie, 60650 Saint-Paul</span>
						 <span>©<?php echo date("Y"); ?> EnerBioFlex</span>
				</section>
				 
		</footer>
	</div>
	</body>
</html>